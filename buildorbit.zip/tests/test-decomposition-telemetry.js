/**
 * Decomposition Telemetry Tests — Phase 4.1
 *
 * Verifies:
 *   1. Telemetry fires on scope_locked (full_product) cases
 *   2. Telemetry fires on soft_expansion cases
 *   3. NO telemetry on clean static_surface classifications
 *   4. NO telemetry on clean light_app classifications
 *   5. Pipeline behavior is completely unchanged with telemetry enabled
 *   6. _computeDecompositionTelemetry structure is correct
 *   7. _logDecompositionTelemetry is fire-and-forget (non-blocking)
 *   8. Telemetry failures do not affect classification result
 *
 * Critical invariant (tested in every case):
 *   The contract returned by classify() must be IDENTICAL whether telemetry
 *   fires or not — the only addition is the optional _decomposition_telemetry
 *   field, which has no effect on pipeline routing.
 */

'use strict';

const {
  classify,
  CONTRACTS,
  _computeDecompositionTelemetry,
} = require('../agents/intent-gate');

let passed = 0;
let failed = 0;

async function test(name, fn) {
  try {
    await fn();
    console.log(`  PASS: ${name}`);
    passed++;
  } catch (e) {
    console.log(`  FAIL: ${name} — ${e.message}`);
    failed++;
  }
}

function assert(condition, msg) {
  if (!condition) throw new Error(msg || 'assertion failed');
}

function assertEqual(actual, expected, msg) {
  if (actual !== expected) {
    throw new Error(`${msg || 'assertion failed'}: expected "${expected}", got "${actual}"`);
  }
}

// ── Section 1: Telemetry fires on scope_locked (full_product) ────────────────

async function main() {
  console.log('\n=== Phase 4.1 Decomposition Telemetry Tests ===\n');

  console.log('--- 1. scope_locked triggers: telemetry attached ---');

  await test('full_product prompt → scope_locked → _decomposition_telemetry present', async () => {
    const contract = await classify('Build a SaaS platform with user accounts', null);
    assert(contract._scope_locked === true, 'Expected _scope_locked=true');
    assert(contract._decomposition_telemetry !== undefined, '_decomposition_telemetry should be attached');
    assert(contract._decomposition_telemetry !== null, '_decomposition_telemetry should not be null');
  });

  await test('scope_locked telemetry has correct action_taken=scope_locked', async () => {
    const contract = await classify('Build a multi-tenant SaaS dashboard', null);
    assert(contract._scope_locked === true, 'Expected scope_locked');
    const dt = contract._decomposition_telemetry;
    assertEqual(dt.action_taken, 'scope_locked', 'action_taken');
    assertEqual(dt.rejection_reason, 'scope_lock_full_product', 'rejection_reason');
  });

  await test('scope_locked telemetry has original_prompt field', async () => {
    const prompt = 'Build a platform with login and registration';
    const contract = await classify(prompt, null);
    assert(contract._scope_locked === true, 'Expected scope_locked');
    const dt = contract._decomposition_telemetry;
    assertEqual(dt.original_prompt, prompt, 'original_prompt should match input');
  });

  await test('scope_locked telemetry has decomposition_candidates array', async () => {
    const contract = await classify('Build a SaaS subscription platform', null);
    assert(contract._scope_locked === true, 'Expected scope_locked');
    const dt = contract._decomposition_telemetry;
    assert(Array.isArray(dt.decomposition_candidates), 'decomposition_candidates should be an array');
    assert(dt.decomposition_candidates.length >= 0, 'decomposition_candidates can be empty if no matches');
    // Each candidate should have class + confidence
    for (const candidate of dt.decomposition_candidates) {
      assert(typeof candidate.class === 'string', 'candidate.class should be string');
      assert(typeof candidate.confidence === 'number', 'candidate.confidence should be number');
      assert(candidate.confidence >= 0 && candidate.confidence <= 1, 'confidence should be 0-1');
    }
  });

  await test('scope_locked telemetry has implied_missing_capabilities array', async () => {
    const contract = await classify('Build a SaaS platform with login and database', null);
    assert(contract._scope_locked === true, 'Expected scope_locked');
    const dt = contract._decomposition_telemetry;
    assert(Array.isArray(dt.implied_missing_capabilities), 'implied_missing_capabilities should be an array');
  });

  await test('scope_locked telemetry has what_system_would_have_done string', async () => {
    const contract = await classify('Build a full-stack SaaS app', null);
    assert(contract._scope_locked === true, 'Expected scope_locked');
    const dt = contract._decomposition_telemetry;
    assert(typeof dt.what_system_would_have_done === 'string', 'what_system_would_have_done should be string');
    assert(dt.what_system_would_have_done.length > 0, 'what_system_would_have_done should not be empty');
  });

  await test('auth prompt in full_product → implied_missing_capabilities includes auth', async () => {
    const contract = await classify('Build a platform with authentication system and login', null);
    assert(contract._scope_locked === true, 'Expected scope_locked');
    const dt = contract._decomposition_telemetry;
    assert(
      dt.implied_missing_capabilities.includes('auth'),
      `Expected "auth" in implied_missing_capabilities, got: [${dt.implied_missing_capabilities.join(', ')}]`
    );
  });

  // ── Section 2: soft_expansion triggers ───────────────────────────────────────

  console.log('\n--- 2. soft_expansion triggers: telemetry attached ---');

  // Soft expansion occurs when entropy is between committed and rejected thresholds.
  // The prompt "build a page for my startup" should trigger soft expansion.
  // However, it depends on pattern matches — let's find a prompt that produces soft_expansion.
  // From the stress test prompts: "build me a page for my startup" → should be ambiguous enough
  // to possibly trigger soft_expansion. Let's test with a few candidates.

  await test('soft_expansion contract → _decomposition_telemetry present', async () => {
    // We need a prompt that triggers soft_expansion (not committed, not rejected)
    // Use classify() and check if we get soft_expansion
    const testPrompts = [
      'build a page for my startup with some features',
      'create an app page for users',
      'make a simple web thing for my product',
    ];

    let foundSoftExpansion = false;
    for (const p of testPrompts) {
      const contract = await classify(p, null);
      if (contract.intent_class === 'soft_expansion') {
        assert(
          contract._decomposition_telemetry !== undefined,
          `soft_expansion contract for "${p}" should have _decomposition_telemetry`
        );
        const dt = contract._decomposition_telemetry;
        assertEqual(dt.action_taken, 'soft_expansion', `action_taken for soft_expansion "${p}"`);
        foundSoftExpansion = true;
        break;
      }
    }

    if (!foundSoftExpansion) {
      // No prompt triggered soft_expansion — not a failure, just note it
      console.log('    (note: no soft_expansion triggered by test prompts — skipping soft_expansion assertion)');
    }
  });

  await test('soft_expansion telemetry has correct action_taken when it fires', async () => {
    // Direct test: build a contract with soft_expansion intent_class to verify
    // _computeDecompositionTelemetry handles it correctly
    const fakeContract = {
      intent_class: 'soft_expansion',
      base_class: 'static_surface',
      expansion_candidate: 'light_app',
      constraints: { frontend: true, server: false, db: false, auth: false, api: false },
    };
    const dt = _computeDecompositionTelemetry('build a page for my app', fakeContract);
    assertEqual(dt.action_taken, 'soft_expansion', 'action_taken should be soft_expansion');
  });

  // ── Section 3: NO telemetry on clean static_surface ─────────────────────────

  console.log('\n--- 3. NO telemetry on clean static_surface ---');

  await test('landing page → static_surface → NO _decomposition_telemetry', async () => {
    const contract = await classify('Build a landing page for BuildOrbit', null);
    assertEqual(contract.intent_class, 'static_surface', 'should be static_surface');
    assert(
      contract._decomposition_telemetry === undefined,
      'static_surface should NOT have _decomposition_telemetry'
    );
  });

  await test('homepage → static_surface → NO _decomposition_telemetry', async () => {
    const contract = await classify('Create a homepage for my startup', null);
    assertEqual(contract.intent_class, 'static_surface', 'should be static_surface');
    assert(
      contract._decomposition_telemetry === undefined,
      'static_surface should NOT have _decomposition_telemetry'
    );
  });

  await test('portfolio → static_surface → NO _decomposition_telemetry', async () => {
    const contract = await classify('Build me a portfolio website', null);
    assertEqual(contract.intent_class, 'static_surface', 'should be static_surface');
    assert(contract._decomposition_telemetry === undefined, 'No telemetry on static_surface');
  });

  // ── Section 4: NO telemetry on clean light_app ───────────────────────────────

  console.log('\n--- 4. NO telemetry on clean light_app ---');

  await test('waitlist form → light_app → NO _decomposition_telemetry', async () => {
    const contract = await classify('Build a waitlist signup form', null);
    assertEqual(contract.intent_class, 'light_app', 'should be light_app');
    assert(
      contract._decomposition_telemetry === undefined,
      'committed light_app should NOT have _decomposition_telemetry'
    );
  });

  await test('calculator → light_app → NO _decomposition_telemetry', async () => {
    const contract = await classify('Build a mortgage calculator', null);
    assertEqual(contract.intent_class, 'light_app', 'should be light_app');
    assert(contract._decomposition_telemetry === undefined, 'No telemetry on light_app');
  });

  await test('contact form → light_app → NO _decomposition_telemetry', async () => {
    const contract = await classify('Build a contact form for my website', null);
    assertEqual(contract.intent_class, 'light_app', 'should be light_app');
    assert(contract._decomposition_telemetry === undefined, 'No telemetry on light_app');
  });

  // ── Section 5: Pipeline behavior unchanged ────────────────────────────────────

  console.log('\n--- 5. Pipeline behavior completely unchanged ---');

  await test('scope_locked: core contract fields identical to pre-telemetry behavior', async () => {
    const contract = await classify('Build a multi-user SaaS platform', null);
    assert(contract._scope_locked === true, 'Expected scope_locked');
    // These are the fields orchestrator depends on — must not change
    assertEqual(contract.intent_class, 'light_app', 'scope_locked returns light_app base');
    assert(contract._classified_as === 'full_product', '_classified_as=full_product');
    assert(typeof contract._scope_lock_suggestion === 'string', 'suggestion present');
    assertEqual(contract._rejected, false, '_rejected=false (deliberate lock, not ambiguous)');
    // _decomposition_telemetry is additive only — does not affect these fields
  });

  await test('static_surface: contract unchanged by telemetry layer', async () => {
    const contract = await classify('Build a landing page for BuildOrbit', null);
    assertEqual(contract.intent_class, 'static_surface', 'intent_class unchanged');
    assertEqual(contract.constraints.server, false, 'server=false unchanged');
    assertEqual(contract.constraints.db, false, 'db=false unchanged');
    assertEqual(contract.constraints.auth, false, 'auth=false unchanged');
    assertEqual(contract.constraints.api, false, 'api=false unchanged');
    assertEqual(contract.expansion_lock, true, 'expansion_lock unchanged');
    assertEqual(contract.complexity_budget, 'low', 'complexity_budget unchanged');
  });

  await test('light_app: contract unchanged by telemetry layer', async () => {
    const contract = await classify('Build a waitlist signup form', null);
    assertEqual(contract.intent_class, 'light_app', 'intent_class unchanged');
    assertEqual(contract.constraints.server, true, 'server=true unchanged');
    assertEqual(contract.constraints.auth, false, 'auth=false unchanged');
    assertEqual(contract.expansion_lock, true, 'expansion_lock unchanged');
  });

  await test('deep copy invariant: multiple calls produce independent contracts', async () => {
    const c1 = await classify('Build a SaaS platform with login', null);
    const c2 = await classify('Build a SaaS platform with login', null);
    assert(c1._scope_locked === true, 'c1 scope_locked');
    assert(c2._scope_locked === true, 'c2 scope_locked');
    // Mutating c1 telemetry should not affect c2 or CONTRACTS template
    if (c1._decomposition_telemetry) {
      c1._decomposition_telemetry.implied_missing_capabilities.push('MUTATED');
    }
    // c2's telemetry should be independent (own copy)
    if (c2._decomposition_telemetry) {
      assert(
        !c2._decomposition_telemetry.implied_missing_capabilities.includes('MUTATED'),
        'c2 telemetry should not be affected by c1 mutation'
      );
    }
    assertEqual(CONTRACTS.static_surface.constraints.server, false, 'CONTRACTS template unchanged');
  });

  // ── Section 6: _computeDecompositionTelemetry structure ──────────────────────

  console.log('\n--- 6. _computeDecompositionTelemetry payload structure ---');

  await test('returns correct fields on scope_locked contract', () => {
    const fakeContract = {
      _scope_locked: true,
      _classified_as: 'full_product',
      intent_class: 'light_app',
    };
    const dt = _computeDecompositionTelemetry('build a SaaS app with auth and database', fakeContract);

    assert(typeof dt.intent === 'string', 'intent field present');
    assertEqual(dt.intent, 'full_product', 'intent should use _classified_as');
    assertEqual(dt.action_taken, 'scope_locked', 'action_taken');
    assertEqual(dt.rejection_reason, 'scope_lock_full_product', 'rejection_reason');
    assert(typeof dt.original_prompt === 'string', 'original_prompt present');
    assert(Array.isArray(dt.decomposition_candidates), 'decomposition_candidates is array');
    assert(Array.isArray(dt.implied_missing_capabilities), 'implied_missing_capabilities is array');
    assert(typeof dt.what_system_would_have_done === 'string', 'what_system_would_have_done string');
    assert(typeof dt._pattern_match_counts === 'object', '_pattern_match_counts present');
  });

  await test('confidence scores are in range [0, 1]', () => {
    const fakeContract = {
      _scope_locked: true,
      _classified_as: 'full_product',
      intent_class: 'light_app',
    };
    const dt = _computeDecompositionTelemetry(
      'build a platform with login, database, and api endpoints',
      fakeContract
    );
    for (const c of dt.decomposition_candidates) {
      assert(c.confidence >= 0 && c.confidence <= 1,
        `Confidence for ${c.class} should be in [0,1], got ${c.confidence}`
      );
    }
  });

  await test('candidates are sorted descending by confidence', () => {
    const fakeContract = {
      _scope_locked: true,
      _classified_as: 'full_product',
      intent_class: 'light_app',
    };
    const dt = _computeDecompositionTelemetry(
      'build a homepage for a SaaS product',
      fakeContract
    );
    const confs = dt.decomposition_candidates.map(c => c.confidence);
    for (let i = 1; i < confs.length; i++) {
      assert(confs[i - 1] >= confs[i],
        `Candidates should be sorted descending: ${confs.join(', ')}`
      );
    }
  });

  await test('zero-match prompt → implied_missing_capabilities is empty', () => {
    const fakeContract = {
      _scope_locked: true,
      _classified_as: 'full_product',
      intent_class: 'light_app',
    };
    // Generic prompt with no capability signals
    const dt = _computeDecompositionTelemetry('build something', fakeContract);
    assert(Array.isArray(dt.implied_missing_capabilities), 'implied_missing_capabilities is array');
    // With no auth/db/api signals, should be empty
    assertEqual(
      dt.implied_missing_capabilities.length,
      0,
      `implied_missing_capabilities should be empty for no-signal prompt, got [${dt.implied_missing_capabilities.join(', ')}]`
    );
  });

  await test('prompt with auth signals → auth in implied_missing_capabilities', () => {
    const fakeContract = { _scope_locked: true, _classified_as: 'full_product', intent_class: 'light_app' };
    const dt = _computeDecompositionTelemetry('build a login and authentication system', fakeContract);
    assert(
      dt.implied_missing_capabilities.includes('auth'),
      'Expected auth in implied_missing_capabilities'
    );
  });

  await test('prompt with db signals → database in implied_missing_capabilities', () => {
    const fakeContract = { _scope_locked: true, _classified_as: 'full_product', intent_class: 'light_app' };
    const dt = _computeDecompositionTelemetry('build something with a database and sql tables', fakeContract);
    assert(
      dt.implied_missing_capabilities.includes('database'),
      'Expected database in implied_missing_capabilities'
    );
  });

  await test('null prompt handled gracefully', () => {
    const fakeContract = { _scope_locked: true, _classified_as: 'full_product', intent_class: 'light_app' };
    const dt = _computeDecompositionTelemetry(null, fakeContract);
    assertEqual(dt.original_prompt, '', 'null prompt → empty string');
    assert(Array.isArray(dt.decomposition_candidates), 'decomposition_candidates still array');
    assert(Array.isArray(dt.implied_missing_capabilities), 'implied_missing_capabilities still array');
  });

  // ── Section 7: _logDecompositionTelemetry is fire-and-forget ─────────────────

  console.log('\n--- 7. _logDecompositionTelemetry is non-blocking ---');

  await test('classify() with mock pool that throws → contract still returned correctly', async () => {
    // If the pool throws on the telemetry insert, classify() should still return normally
    const throwingPool = {
      query: () => Promise.reject(new Error('DB connection refused')),
    };
    const fakeRunId = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';

    // full_product prompt triggers scope_lock + telemetry logging
    // The throwing pool should cause a warning but NOT throw to caller
    let contract;
    try {
      contract = await classify('Build a multi-tenant SaaS platform', throwingPool, fakeRunId);
    } catch (err) {
      throw new Error(`classify() should not throw when telemetry pool fails: ${err.message}`);
    }

    assert(contract !== undefined && contract !== null, 'contract returned despite pool failure');
    assert(contract._scope_locked === true, 'scope_locked still correct');
    // Telemetry was still computed (just DB insert failed)
    assert(contract._decomposition_telemetry !== undefined, 'telemetry computed despite DB failure');
  });

  await test('classify() without pool or runId → telemetry computed but not logged', async () => {
    // No pool, no runId → DB logging skipped entirely (no-op)
    const contract = await classify('Build a SaaS platform with user authentication', null, null);
    assert(contract._scope_locked === true, 'scope_locked');
    // Telemetry should still be computed (just not logged to DB)
    assert(contract._decomposition_telemetry !== undefined, 'telemetry computed without pool');
  });

  // ── Section 8: Telemetry failures don't affect classification ─────────────────

  console.log('\n--- 8. Telemetry failures do not affect classification result ---');

  await test('classification result identical with or without pool for non-telemetry paths', async () => {
    const withPool = await classify('Build a landing page', null);
    const withoutPool = await classify('Build a landing page');

    // Both should return static_surface with identical core fields
    assertEqual(withPool.intent_class, withoutPool.intent_class, 'intent_class matches');
    assertEqual(withPool.complexity_budget, withoutPool.complexity_budget, 'complexity_budget matches');
    assertEqual(withPool.constraints.server, withoutPool.constraints.server, 'constraints.server matches');
    assertEqual(withPool.constraints.db, withoutPool.constraints.db, 'constraints.db matches');
  });

  // ── Summary ───────────────────────────────────────────────────────────────────

  console.log('\n');
  console.log(`=== Results: ${passed} passed, ${failed} failed ===`);
  console.log('');

  if (failed > 0) {
    process.exit(1);
  }
}

main().catch(err => {
  console.error('Test runner error:', err);
  process.exit(1);
});
